<?php

define("ABSPATH", __DIR__. "/");
define("ABSPATH_SITE", ABSPATH . "site" . "/");

// Khách hàng sẽ dô đây để config
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");
define("DBNAME", "backend_godashop");

define("ITEM_PER_PAGE", 9);

define("GOOGLE_RECAPTCHA_SITE", "6LcUVugpAAAAAFt8TpG_o1FRHK-sdAGI2PkOJc4Y");
define("GOOGLE_RECAPTCHA_SECRET", "6LcUVugpAAAAALcFDs32Tc1LRYLQscv90cL1Dxr_");

define("SMTP_USERNAME", "nguyenphuochao456@gmail.com");
define("SMTP_SECRET", "aqehzdwwqqrxdlwz");
define("SMTP_HOST", "smtp.gmail.com");

define("JWT_KEY", "godashop-key");

define("SHOP_OWNER", "nguyenphuochao456@gmail.com");

// cấu hình google,facebook

define("GOOGLE_CLIENT_ID", "464162272047-q6j70ln2ge4eagbisedr091af5v3mg75.apps.googleusercontent.com");
define("GOOGLE_CLIENT_SECRET", "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");

define("FACEBOOK_CLIENT_ID", "1357135002345180");
define("FACEBOOK_CLIENT_SECRET", "2977b77a7819350705e60570e14dd937");